/*
 * Implementation is in EthernetServerStream.h to avoid linker issues.
 */
