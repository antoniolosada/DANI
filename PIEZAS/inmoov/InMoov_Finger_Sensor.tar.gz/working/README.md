####**This is the InMoov finger sensors which can be mounted on the hands.**
These sensors are done with 2 small coppers plates and piece of carbon Foam.
Find More info here:
[http://www.inmoov.fr]
Tutorial here:
[http://www.inmoov.fr/hand-and-forarm/]