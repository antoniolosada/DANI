# Here is "InMoov", the robot you can print and animate. You have a 3D printer, some building skills, This project is for you!!

Don't be scared or intimidated, I started this a few months ago and didn't even know what was Arduino or a servo motor!

Start with printing the hand like I did, and go on the rest if you feel.

(http://www.thingiverse.com/thing:17773)

These are the parts of the Chest, You can find detailed assembly sketchs on the website.

Blog with more info and instructions:
(http://www.inmoov.fr

(http://inmoov.blogspot.com)

(http://inmoov.blogspot.fr/p/assembly-help.html)



These videos aren't all actual, I have modified some parts in between:

(http://www.youtube.com/watch?v=QriZcazVxgo)

(http://www.youtube.com/watch?v=W62Wfz1xqYg)

(http://www.youtube.com/watch?v=tojIdfywYVI)

(http://www.youtube.com/watch?v=BAs2F4sFVdA)



----
