**Okay here you will find the Top Stomach parts.**
Stomach is composed of three levels:
Top stomach.
Mid stomach.
Low stomach

You can find more info on:
[InMoov site](http://www.inmoov.fr)

The tutorial:
http://www.inmoov.fr/top-stomach/